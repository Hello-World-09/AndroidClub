import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import CustomTabNavigation from './CustomTabNavigation';
import CustomHomeScreen from './screens/CustomHomeScreen';
import CustomSettingsScreen from './screens/CustomSettingsScreen'; 

const CustomDrawer = createDrawerNavigator();

const CustomDrawerNavigation = () => {
  return (
    <CustomDrawer.Navigator initialRouteName="CustomTabs">
      <CustomDrawer.Screen name="CustomTabs" component={CustomTabNavigation} />
      <CustomDrawer.Screen name="CustomHome" component={CustomHomeScreen} />
      <CustomDrawer.Screen name="CustomSettings" component={CustomSettingsScreen} />
    </CustomDrawer.Navigator>
  );
};

export default CustomDrawerNavigation;
