import React from 'react';
import { View, Text } from 'react-native';

const CustomProfileScreen = () => {
  return (
    <View>
      <Text>Custom Profile Screen</Text>
    </View>
  );
};

export default CustomProfileScreen;
