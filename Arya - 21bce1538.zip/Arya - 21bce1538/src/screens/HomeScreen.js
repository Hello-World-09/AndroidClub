import React from 'react';
import { View, Text } from 'react-native';

const CustomHomeScreen = () => {
  return (
    <View>
      <Text>Custom Home Screen</Text>
    </View>
  );
};

export default CustomHomeScreen;
