import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import CustomHomeScreen from './screens/CustomHomeScreen'; 
import CustomProfileScreen from './screens/CustomProfileScreen';
import CustomSettingsScreen from './screens/CustomSettingsScreen';
import CustomNotificationsScreen from './screens/CustomNotificationsScreen';
const CustomTab = createBottomTabNavigator();

const CustomTabNavigation = () => {
  return (
    <CustomTab.Navigator>
      <CustomTab.Screen name="CustomHome" component={CustomHomeScreen} />
      <CustomTab.Screen name="CustomProfile" component={CustomProfileScreen} />
      <CustomTab.Screen name="CustomSettings" component={CustomSettingsScreen} />
      <CustomTab.Screen name="CustomNotifications" component={CustomNotificationsScreen} />
    </CustomTab.Navigator>
  );
};

export default CustomTabNavigation;
